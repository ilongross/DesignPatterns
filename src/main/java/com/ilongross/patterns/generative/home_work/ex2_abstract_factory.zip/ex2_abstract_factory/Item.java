package com.ilongross.patterns.lection1.generative.home_work.ex2_abstract_factory;

public interface Item {

}
