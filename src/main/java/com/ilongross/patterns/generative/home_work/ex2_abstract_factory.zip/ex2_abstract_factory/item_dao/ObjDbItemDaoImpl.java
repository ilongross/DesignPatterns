package com.ilongross.patterns.lection1.generative.home_work.ex2_abstract_factory.item_dao;

import com.ilongross.patterns.lection1.generative.home_work.ex2_abstract_factory.Id;
import com.ilongross.patterns.lection1.generative.home_work.ex2_abstract_factory.Item;

public class ObjDbItemDaoImpl implements ItemDao{
    @Override
    public void crete(Item item) {

    }

    @Override
    public Item read(Id id) {
        return null;
    }

    @Override
    public void update(Item item) {

    }

    @Override
    public void delete(Item item) {

    }
}
