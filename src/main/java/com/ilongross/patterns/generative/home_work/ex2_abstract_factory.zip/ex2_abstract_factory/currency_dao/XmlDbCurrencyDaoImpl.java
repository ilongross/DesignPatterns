package com.ilongross.patterns.lection1.generative.home_work.ex2_abstract_factory.currency_dao;

import com.ilongross.patterns.lection1.generative.home_work.ex2_abstract_factory.Id;
import com.ilongross.patterns.lection1.generative.home_work.ex2_abstract_factory.currency_dao.CurrencyDao;

import java.util.Currency;

public class XmlDbCurrencyDaoImpl implements CurrencyDao {
    @Override
    public void create(Currency currency) {

    }

    @Override
    public Currency read(Id id) {
        return null;
    }

    @Override
    public void update(Currency currency) {

    }

    @Override
    public void delete(Currency currency) {

    }
}
