package com.ilongross.patterns.lection1.generative.home_work.ex1_file_system;

public interface FSItem {
    String getName();
    void setName(String name);
    String getPath();
    FSItem getParent();
}
