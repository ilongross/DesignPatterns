package com.ilongross.patterns.lection2.structure.composite.home_work_lab3.interfaces;

public interface Product {
    int countCalories();
}
